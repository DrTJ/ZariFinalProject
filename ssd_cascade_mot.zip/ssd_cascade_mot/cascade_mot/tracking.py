"""Deep SORT tracking on top of any detection strategy.

Uses the `deep-sort-realtime` package: a Kalman filter predicts each track's
motion, and a MobileNetV2 appearance embedding plus the Hungarian algorithm
associates new detections with existing tracks (the same building blocks
described in the thesis).
"""
from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass

import numpy as np
from deep_sort_realtime.deepsort_tracker import DeepSort

from .detectors import Detections


@dataclass
class TrackOut:
    track_id: int
    ltrb: tuple[float, float, float, float]
    label: int | None


class Tracker:
    def __init__(self, max_age: int = 30, n_init: int = 3, max_iou_distance: float = 0.7,
                 max_cosine_distance: float = 0.2, nn_budget: int | None = 100,
                 embedder_gpu: bool = False, half: bool = False, min_box: float = 4.0):
        self.min_box = min_box
        self.kwargs = dict(max_age=max_age, n_init=n_init, max_iou_distance=max_iou_distance,
                           max_cosine_distance=max_cosine_distance, nn_budget=nn_budget,
                           embedder="mobilenet", half=half, bgr=True, embedder_gpu=embedder_gpu)
        self.reset()

    def reset(self):
        self.ds = DeepSort(**self.kwargs)
        self.total_time = 0.0
        self.frames = 0
        self.track_lengths: dict[int, int] = defaultdict(int)

    def update(self, frame_bgr: np.ndarray, dets: Detections) -> list[TrackOut]:
        t0 = time.perf_counter()
        h, w = frame_bgr.shape[:2]
        raw = []
        for (x1, y1, x2, y2), s, l in zip(dets.boxes, dets.scores, dets.labels):
            # Clip to the frame and skip degenerate boxes: they would give the
            # appearance embedder an empty crop and crash it.
            x1, x2 = max(0.0, float(x1)), min(float(w), float(x2))
            y1, y2 = max(0.0, float(y1)), min(float(h), float(y2))
            if x2 - x1 < self.min_box or y2 - y1 < self.min_box:
                continue
            raw.append(([x1, y1, x2 - x1, y2 - y1], float(s), int(l)))
        tracks = self.ds.update_tracks(raw, frame=frame_bgr)
        out = []
        for t in tracks:
            # Report confirmed tracks that were matched to a detection this frame.
            if not t.is_confirmed() or t.time_since_update > 0:
                continue
            tid = int(t.track_id)
            self.track_lengths[tid] += 1
            out.append(TrackOut(tid, tuple(float(v) for v in t.to_ltrb()), t.get_det_class()))
        self.total_time += time.perf_counter() - t0
        self.frames += 1
        return out

    @property
    def mean_ms(self) -> float:
        return 1000 * self.total_time / max(self.frames, 1)

    def summary(self) -> dict:
        lengths = list(self.track_lengths.values())
        return {
            "unique_ids": len(lengths),
            "mean_track_len": float(np.mean(lengths)) if lengths else 0.0,
            # Many short tracks usually mean fragmentation / ID switches.
            "short_tracks(<10f)": int(sum(1 for n in lengths if n < 10)),
        }
